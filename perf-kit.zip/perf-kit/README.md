# Backend Performance Kit — autocannon + clinic + prom-client + Prometheus/Grafana + pino

k6 ছাড়া, Ubuntu তে। Express + MongoDB + Redis + BullMQ backend এর জন্য।

| Tool | কাজ | কখন দেখবে |
|---|---|---|
| **autocannon** (`perf/run.mjs`) | Load দেয়, pass/fail বলে | Test শেষে terminal এ, আর `perf/results/` এ |
| **prom-client** (`src/observability/metrics.js`) | App এর ভেতরের number বের করে `/metrics` এ | নিজে পড়বে না, Prometheus পড়বে |
| **Prometheus + Grafana** (`docker-compose.monitoring.yml`) | Number জমা রাখে আর graph দেখায় | **Test চলার সময় live** দেখবে, `http://localhost:3001` এ |
| **clinic** | কোন function CPU খাচ্ছে | Test শেষে browser এ খোলা HTML report এ |
| **pino** (`src/observability/logger.js`) | প্রতিটা request এর log, request-id সহ | যখন কোনো নির্দিষ্ট slow বা failed request খুঁজবে |

---

## ধাপ ১ — Install (একবারই)

File গুলো তোমার backend এ copy করো:

```
backend/
├── perf/
│   ├── run.mjs              ← runner (edit করতে হবে না)
│   └── scenarios.mjs        ← তোমার endpoint, traffic mix, threshold (এটা edit করবে)
├── src/observability/
│   ├── metrics.js
│   └── logger.js
├── monitoring/              ← Prometheus + Grafana config, dashboard
└── docker-compose.monitoring.yml
```

```bash
cd backend
npm i prom-client pino pino-http
npm i -D autocannon pino-pretty
npm i -g clinic
```

`package.json` এ এই script গুলো যোগ করো:

```json
"scripts": {
  "perf:smoke":  "node perf/run.mjs smoke",
  "perf:load":   "node perf/run.mjs load",
  "perf:stress": "node perf/run.mjs stress",
  "perf:spike":  "node perf/run.mjs spike",
  "perf:soak":   "node perf/run.mjs soak",
  "perf:compare":"node perf/run.mjs compare",
  "monitor:up":  "docker compose -f docker-compose.monitoring.yml up -d",
  "monitor:down":"docker compose -f docker-compose.monitoring.yml down"
}
```

> `metrics.js` আর `logger.js` ESM (`import`) এ লেখা। তোমার project CommonJS (`require`) হলে `import` কে `require` আর `export` কে `module.exports` এ বদলে নিও।

---

## ধাপ ২ — App এ metrics আর log বসাও (একবারই)

```js
// app.js
import { metricsMiddleware, metricsHandler, trackMongoose, trackQueue } from "./observability/metrics.js";
import { httpLogger } from "./observability/logger.js";

app.use(metricsMiddleware);          // সব route এর আগে
app.use(httpLogger);
app.get("/metrics", metricsHandler);

// MongoDB command এর সময় মাপতে monitorCommands চালু করতে হবে
await mongoose.connect(process.env.MONGO_URI, { monitorCommands: true });
trackMongoose(mongoose);

trackQueue(emailQueue);              // প্রতিটা BullMQ Queue এর জন্য
```

Handler এর ভেতরে `console.log` এর বদলে `req.log.info({ orderId }, "order created")` ব্যবহার করো।

**ঠিকমতো বসেছে কিনা check:**
```bash
node dist/server.js | npx pino-pretty
curl localhost:5000/metrics | grep http_request_duration
```
`http_request_duration_seconds_count{method="GET",route="/api/v1/products",...}` এরকম লাইন এলে সব ঠিক আছে।

---

## ধাপ ৩ — Grafana চালু করো

```bash
npm run monitor:up
```

- `http://localhost:9090/targets` খোলো। `api` এর পাশে **UP** থাকলে Prometheus তোমার app থেকে data পাচ্ছে।
- `http://localhost:3001` খোলো আর `admin` / `admin` দিয়ে login করো। **"Backend Performance"** dashboard আগে থেকেই load করা থাকবে, data source ও set করা আছে।

DOWN দেখালে: API port 5000 এ না চললে `monitoring/prometheus.yml` এ port বদলাও। আর API কে `localhost` এ listen করাতে হবে (`app.listen(5000)` default এ ঠিক থাকে)।

Dashboard এ যা আছে:

| Row | Panel |
|---|---|
| উপরের ৬টা box | Req/s, p95, 5xx rate, event loop lag, CPU, in-flight requests। সবুজ মানে ঠিক, কমলা মানে সাবধান, লাল মানে সমস্যা |
| HTTP | প্রতিটা route এর p95 আর req/s, status code, p50/p95/p99 |
| Node.js | Event loop lag, CPU, heap/RSS memory, GC time |
| MongoDB & queue | Collection অনুযায়ী DB p95, DB ops/sec, BullMQ waiting/active/failed |

---

## ধাপ ৪ — `perf/scenarios.mjs` এডিট করো

এই একটা file এ চারটা জিনিস ঠিক করতে হয়:

1. **`mix`**: কোন endpoint কত % traffic পাবে। `path` একটা function হলে প্রতি request এ নতুন value তৈরি হয় (random category বা id)। Phase 2 এর perf DB থেকে কিছু আসল `productIds` বসাও, তাহলে test বাস্তবের মতো হবে।
2. **`login`**: test user এর email/password আর response এর কোথায় token থাকে (`tokenPath`)। চাইলে `TOKEN=xxx` env দিয়েও সরাসরি token দিতে পারো।
3. **`thresholds`**: কোন number পার হলে FAIL ধরা হবে।
4. **`profiles`**: প্রতিটা test কত connection দিয়ে কত সেকেন্ড চলবে।

> autocannon p95 দেয় না, তাই এখানে **p97.5 আর p99** দিয়ে threshold দেওয়া হয়েছে। এটা p95 এর চেয়েও কড়া। Grafana তে p95 দেখা যায়।

---

## ধাপ ৫ — Test চালাও

API চালু করো Phase 2 এর perf DB এর সাথে (million data), production mode এ:

```bash
ulimit -n 65535
NODE_ENV=production MONGO_URI=mongodb://localhost:27018/app_perf node dist/server.js >> logs/app.log
```

অন্য terminal এ:

| Command | কী করে | কতক্ষণ |
|---|---|---|
| `npm run perf:smoke` | ৪টা connection দিয়ে check করে script আর API ঠিক আছে কিনা। **সবসময় এটা আগে চালাও** | ২০ সেকেন্ড |
| `npm run perf:load` | স্বাভাবিক load এ threshold pass করে কিনা | ~৬ মিনিট |
| `npm run perf:stress` | Connection ধাপে ধাপে বাড়ায়, আর যেখানে threshold ভাঙে সেখানে থামে। এতে breaking point জানা যায় | ১–৬ মিনিট |
| `npm run perf:spike` | হঠাৎ ২৫ গুণ traffic দেয়, তারপর দেখে স্বাভাবিক অবস্থায় ফেরে কিনা | ~২.৫ মিনিট |
| `npm run perf:soak` | ২ ঘণ্টা একটানা চালায়, memory leak খোঁজার জন্য | ২ ঘণ্টা |

**Test চলার সময় Grafana খুলে রাখো।** এটাই live দেখার জায়গা।

### Output কীভাবে পড়বে

```
── Stage 2 · 100 conn · 300s · 1,559 req/s · errors 0% ✓
  scenario          conn    req/s     p50   p97.5     p99     max  non2xx   err
  browse              60      980       5      14      22      90       0     0
  search              10       23      51     180     240     310       0     0
  server: event loop lag max 22.9ms · CPU ~85% · heap 61 → 74 MB (max 80)

• Capacity: 50 connections ≈ 1,559 req/s within thresholds
• Breaking point: 300 connections → search: p99 3,798ms > 500ms; event loop lag 215ms > 100ms
RESULT: ✓ PASS
```

| জিনিস | মানে |
|---|---|
| `req/s` | সেকেন্ডে কতগুলো request সামলাচ্ছে |
| `p97.5` / `p99` | সবচেয়ে slow দিকের request কত সময় নিচ্ছে। **avg দেখবে না** |
| `non2xx` / `err` | 4xx/5xx আর connection error বা timeout। ০ না হলে আগে এগুলো ঠিক করো |
| `server:` লাইন | `/metrics` থেকে নেওয়া: event loop lag, CPU আর heap |
| `Capacity` (stress) | Threshold এর মধ্যে থেকে সর্বোচ্চ কত load নিতে পারে |
| `Breaking point` (stress) | কোন load এ, কী কারণে ভেঙেছে |
| `Recovery` (spike) | Spike এর পর p99 আগের ১.৫ গুণের মধ্যে ফিরলে recovered ✓ |
| `Heap` (soak) | ২ ঘণ্টায় heap ৫০% এর বেশি বাড়লে memory leak থাকতে পারে |
| `0 completed responses` | Server overload, এই scenario এর একটা request ও শেষ হয়নি। Latency 0 দেখালেও এটা FAIL |
| `RESULT` + exit code | FAIL হলে exit code 1, তাই CI ও fail করবে |

প্রতিটা run `perf/results/<profile>-<time>.json` আর `.md` হিসেবে save হয়।

---

## ধাপ ৬ — আগে/পরে তুলনা (প্রতিটা optimization এর পর)

```bash
npm run perf:load                     # baseline
# একটা জিনিস বদলাও (index, .lean(), cache...), rebuild, restart
npm run perf:load
npm run perf:compare perf/results/load-<আগের>.json perf/results/load-<পরের>.json
```

```
scenario            req/s before     after          Δ   p99 before      after          Δ
browse                       983     1,410     +43.4%         92ms       31ms     -66.3%
TOTAL                      1,632     2,050     +25.6%
```
Req/s বাড়লে আর p99 কমলে পরিবর্তনটা কাজ করেছে। **একবারে একটাই জিনিস বদলাবে**, নাহলে বুঝবে না কোনটার কারণে উন্নতি হলো।

---

## ধাপ ৭ — Bottleneck খোঁজা (Grafana তে সমস্যা দেখলে)

Grafana দেখে আগে ঠিক করো সমস্যাটা কোন ধরনের:

| Grafana তে যা দেখছ | মানে | পরের কাজ |
|---|---|---|
| CPU ~১০০% আর event loop lag বেশি | JS code CPU আটকে রাখছে | **clinic flame** |
| CPU কম কিন্তু p95 বেশি, MongoDB p95 ও বেশি | DB slow | Phase 2 এর query report দেখো, ওই collection এর query ঠিক করো |
| CPU কম, DB fast, কিন্তু p95 বেশি | Redis, external API বা connection pool এর জন্য অপেক্ষা | **clinic bubbleprof** |
| Heap বাড়তেই থাকে | Memory leak | `clinic heapprofiler`, বা soak চালিয়ে heap snapshot নাও |
| BullMQ waiting বাড়তেই থাকে | Worker কাজের গতির সাথে তাল রাখতে পারছে না | Worker concurrency বাড়াও বা job এর কাজ হালকা করো |

### clinic + এই runner একসাথে

```bash
# terminal 1 — clinic দিয়ে API চালাও (nodemon বা ts-node দিয়ে না)
NODE_ENV=production clinic flame -- node dist/server.js

# terminal 2 — আসল traffic mix দিয়ে load দাও
npm run perf:load

# load শেষ হলে terminal 1 এ Ctrl+C → browser এ flame graph খুলবে
```
Flame graph এ চওড়া box মানে বেশি CPU খরচ। নিজের `src/` এর function গুলো আগে খোঁজো।

একটা endpoint কে দ্রুত profile করতে চাইলে clinic এর built-in autocannon ও ব্যবহার করা যায়:
```bash
clinic doctor --autocannon [ -c 50 -d 30 "/api/v1/products?category=laptop" ] -- node dist/server.js
```

---

## ধাপ ৮ — নির্দিষ্ট slow request খোঁজা (pino)

```bash
# ৫০০ms এর বেশি সময় নেওয়া request
jq -c 'select(.responseTime > 500) | {t:.time, id:.req.id, url:.req.url, ms:.responseTime, status:.res.statusCode}' logs/app.log | head

# সব 5xx error
jq -c 'select(.res.statusCode >= 500)' logs/app.log

# একটা request এর সব log line (frontend থেকে x-request-id পেলে)
grep "dda88f8d-4eda-43a1" logs/app.log | npx pino-pretty

# কোন URL সবচেয়ে বেশি slow
jq -r 'select(.responseTime > 500) | .req.url' logs/app.log | sed 's/?.*//' | sort | uniq -c | sort -rn | head
```
`jq` না থাকলে install করো: `sudo apt install jq`। Response এর `x-request-id` header টা frontend আর dashboard এর error message এ দেখালে bug report করা অনেক সহজ হয়।

---

## পুরো session এক নজরে

```
npm run monitor:up                          → Grafana চালু (একবার)
API চালাও (perf DB, NODE_ENV=production)
npm run perf:smoke                          → সব ঠিকমতো চলছে কিনা
npm run perf:load    + Grafana খোলা         → SLO pass করছে কিনা, live দেখো
npm run perf:stress                         → capacity আর breaking point
সমস্যা পেলে → Grafana দিয়ে ধরন বোঝো → clinic / Phase 2 report / pino log
Fix → perf:load আবার → perf:compare
release এর আগে → perf:spike, perf:soak
```

**মনে রাখো:** autocannon বলে সমস্যা আছে কিনা, Grafana বলে কোথায় আর কখন, clinic বলে কোন function এ, আর pino বলে কোন নির্দিষ্ট request এ।

## সাবধানতা
- Production server এ load test বা clinic চালাবে না।
- autocannon আর API একই machine এ চললে CPU ভাগাভাগি হয়, তাই result কিছুটা খারাপ আসে। আগে/পরে তুলনার জন্য এটা সমস্যা না। আসল capacity মাপতে runner আলাদা machine থেকে চালাও: `BASE_URL=http://<server-ip>:5000 npm run perf:load`
- `/metrics` production এ public রাখবে না। `METRICS_TOKEN` env set করো, আর `prometheus.yml` এ token দাও।
