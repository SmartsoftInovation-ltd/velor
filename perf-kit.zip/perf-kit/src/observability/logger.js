// Structured logging with request id
// npm i pino pino-http   ·   npm i -D pino-pretty
//
// app.js:
//   import { logger, httpLogger } from "./observability/logger.js";
//   app.use(httpLogger);                       // সব route এর আগে
//   req.log.info({ orderId }, "order created"); // handler এর ভেতরে console.log এর বদলে
//   logger.error({ err }, "worker crashed");    // request এর বাইরে (worker, cron)
//
// Dev:  node dist/server.js | npx pino-pretty
// Prod: node dist/server.js >> logs/app.log

import pino from "pino";
import pinoHttp from "pino-http";
import { randomUUID } from "node:crypto";

export const logger = pino({
  level: process.env.LOG_LEVEL ?? "info",
  base: { service: process.env.SERVICE_NAME ?? "api" },
  timestamp: pino.stdTimeFunctions.isoTime,
  // secret কখনো log এ যাবে না
  redact: {
    paths: ["req.headers.authorization", "req.headers.cookie", 'res.headers["set-cookie"]', "*.password", "*.token", "*.refreshToken"],
    censor: "[redacted]",
  },
});

export const httpLogger = pinoHttp({
  logger,
  genReqId: (req, res) => {
    const id = req.headers["x-request-id"] || randomUUID();
    res.setHeader("x-request-id", id); // frontend / dashboard এ এই id দেখাও, bug report এ কাজে লাগবে
    return id;
  },
  customLogLevel: (req, res, err) => (err || res.statusCode >= 500 ? "error" : res.statusCode >= 400 ? "warn" : "info"),
  // /metrics আর health check log করার দরকার নেই
  autoLogging: { ignore: (req) => ["/metrics", "/health", "/ready"].includes(req.url) },
  serializers: {
    req: (req) => ({ id: req.id, method: req.method, url: req.url, ip: req.remoteAddress }),
    res: (res) => ({ statusCode: res.statusCode }),
  },
});
