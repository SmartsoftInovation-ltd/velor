// Prometheus metrics for Express + Mongoose + BullMQ
// npm i prom-client
//
// app.js:
//   import { metricsMiddleware, metricsHandler, trackMongoose, trackQueue } from "./observability/metrics.js";
//   app.use(metricsMiddleware);                 // সব route এর আগে
//   app.get("/metrics", metricsHandler);         // production এ public রাখবে না (নিচে দেখো)
//   trackMongoose(mongoose);                     // mongoose.connect(uri, { monitorCommands: true }) লাগবে
//   trackQueue(emailQueue);                      // প্রতিটা BullMQ Queue এর জন্য

import client from "prom-client";

// CPU, memory, heap, GC, event loop lag — automatic
client.collectDefaultMetrics({ eventLoopMonitoringPrecision: 10 });

const httpDuration = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "HTTP request duration in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.2, 0.5, 1, 2, 5],
});

const httpInFlight = new client.Gauge({
  name: "http_requests_in_flight",
  help: "Requests currently being processed",
});

export function metricsMiddleware(req, res, next) {
  if (req.path === "/metrics") return next();
  const end = httpDuration.startTimer();
  httpInFlight.inc();
  res.on("finish", () => {
    httpInFlight.dec();
    // route pattern (/api/v1/products/:id), আসল URL না — নাহলে প্রতিটা id আলাদা series হয়ে যাবে
    const route = req.route ? `${req.baseUrl}${req.route.path}` : "unmatched";
    end({ method: req.method, route, status: res.statusCode });
  });
  next();
}

export async function metricsHandler(req, res) {
  // Production এ token দিয়ে আটকাও: METRICS_TOKEN set করলে header লাগবে
  const token = process.env.METRICS_TOKEN;
  if (token && req.headers.authorization !== `Bearer ${token}`) return res.status(401).end();
  res.set("Content-Type", client.register.contentType);
  res.end(await client.register.metrics());
}

// ---- MongoDB: প্রতিটা DB command কত সময় নিচ্ছে (app time vs DB time আলাদা করতে) ----
const dbDuration = new client.Histogram({
  name: "mongodb_command_duration_seconds",
  help: "MongoDB command duration in seconds",
  labelNames: ["command", "collection", "ok"],
  buckets: [0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2],
});

export function trackMongoose(mongoose) {
  const attach = () => {
    const mc = mongoose.connection.getClient();
    const pending = new Map();
    mc.on("commandStarted", (e) => {
      const coll = e.command?.[e.commandName];
      pending.set(e.requestId, typeof coll === "string" ? coll : "-");
      if (pending.size > 10000) pending.clear(); // safety
    });
    const done = (ok) => (e) => {
      const collection = pending.get(e.requestId) ?? "-";
      pending.delete(e.requestId);
      if (["hello", "isMaster", "ping", "saslStart", "saslContinue", "endSessions"].includes(e.commandName)) return;
      dbDuration.observe({ command: e.commandName, collection, ok }, e.duration / 1000);
    };
    mc.on("commandSucceeded", done("1"));
    mc.on("commandFailed", done("0"));
  };
  if (mongoose.connection.readyState === 1) attach();
  else mongoose.connection.once("connected", attach);
}

// ---- BullMQ: queue backlog ----
const queueJobs = new client.Gauge({
  name: "bullmq_jobs",
  help: "BullMQ job counts by state",
  labelNames: ["queue", "state"],
});
const queues = new Set();
export function trackQueue(queue) {
  queues.add(queue);
}
// Prometheus scrape এর সময় count নেয়
new client.Gauge({
  name: "bullmq_scrape_ok",
  help: "1 if queue counts were collected",
  async collect() {
    let ok = 1;
    for (const q of queues) {
      try {
        const c = await q.getJobCounts("waiting", "active", "delayed", "failed");
        for (const [state, n] of Object.entries(c)) queueJobs.set({ queue: q.name, state }, n);
      } catch { ok = 0; }
    }
    this.set(ok);
  },
});

export { client };
