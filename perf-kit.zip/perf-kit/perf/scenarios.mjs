// ────────────────────────────────────────────────────────────────
// এই file টা তোমার API অনুযায়ী edit করো। runner (perf/run.mjs) এটাই পড়ে।
// ────────────────────────────────────────────────────────────────

export const baseUrl = process.env.BASE_URL ?? "http://localhost:5000";

// /metrics থেকে event loop lag, heap, CPU পড়ে result এ যোগ করবে (না থাকলে skip)
export const metricsUrl = process.env.METRICS_URL ?? `${baseUrl}/metrics`;

// Auth: TOKEN env দিলে সেটাই ব্যবহার হবে। না দিলে নিচের login একবার call করে token নেবে।
export const login = {
  path: "/api/v1/auth/login",
  body: { email: process.env.PERF_EMAIL ?? "perf@test.com", password: process.env.PERF_PASSWORD ?? "Password123!" },
  tokenPath: "data.accessToken", // response JSON এর কোথায় token আছে
};

// Random id দিয়ে test করলে cache সব সময় hit হয় না — বাস্তবের মতো।
// Phase 2 perf DB থেকে কিছু আসল id এখানে বসাও (বা একটা JSON file থেকে load করো)।
const productIds = ["665f1c2e8b3e4a0012345678", "665f1c2e8b3e4a0012345679"];
const categories = ["mobile", "laptop", "camera", "audio"];
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

// Traffic mix: weight = মোট connection এর কত % এই scenario পাবে।
// path / body function হলে প্রতিটা request এ নতুন value তৈরি হবে।
export const mix = [
  {
    name: "browse",
    weight: 60,
    requests: [{ method: "GET", path: () => `/api/v1/products?category=${pick(categories)}&limit=20` }],
  },
  {
    name: "product-detail",
    weight: 20,
    requests: [{ method: "GET", path: () => `/api/v1/products/${pick(productIds)}` }],
  },
  {
    name: "search",
    weight: 10,
    requests: [{ method: "GET", path: () => `/api/v1/products/search?q=${pick(["cam", "lens", "pro", "max"])}` }],
  },
  {
    name: "order",
    weight: 10,
    auth: true,
    requests: [{ method: "POST", path: "/api/v1/orders", body: () => ({ productId: pick(productIds), qty: 1 }) }],
  },
];

// Pass/fail rule (k6 এর thresholds এর মতো)। যেকোনো একটা ভাঙলে exit code 1 → CI fail।
// autocannon p95 দেয় না, তাই p97.5 আর p99 ব্যবহার করা হয়েছে (আরও কড়া)।
export const thresholds = {
  p97_5Ms: 250,      // প্রতিটা scenario
  p99Ms: 500,        // প্রতিটা scenario
  errorRate: 0.005,  // সব scenario মিলিয়ে (errors + timeouts + non-2xx) / total
  eventLoopLagMs: 100, // /metrics থাকলে
};

// Profile = কোন ধাপে কত connection কত সেকেন্ড।
export const profiles = {
  smoke: [{ connections: 4, duration: 20 }],
  load: [
    { connections: 50, duration: 60 },   // warm-up
    { connections: 100, duration: 300 }, // target load
  ],
  stress: [50, 100, 200, 400, 800, 1200].map((c) => ({ connections: c, duration: 60 })), // threshold ভাঙলে থামবে
  spike: [
    { connections: 20, duration: 60, label: "before" },
    { connections: 500, duration: 30, label: "spike" },
    { connections: 20, duration: 60, label: "recovery" },
  ],
  soak: [{ connections: 80, duration: 2 * 60 * 60 }], // ২ ঘণ্টা — memory leak খোঁজার জন্য
};
