#!/usr/bin/env node
// autocannon-based load runner — k6 ছাড়াই smoke / load / stress / spike / soak
//
//   node perf/run.mjs smoke|load|stress|spike|soak     → test চালায়, perf/results/ এ JSON + MD
//   node perf/run.mjs compare <before.json> <after.json> → আগে/পরে তুলনা
//
// Env: BASE_URL, TOKEN, METRICS_URL, PERF_EMAIL, PERF_PASSWORD
// Requires: npm i -D autocannon

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import autocannon from "autocannon";

const here = path.dirname(fileURLToPath(import.meta.url));
const resultsDir = path.join(here, "results");
const cfg = await import(path.join(here, "scenarios.mjs"));

const fmt = (n, d = 0) => (n == null || Number.isNaN(n) ? "—" : Number(n).toLocaleString("en-US", { maximumFractionDigits: d }));
const pad = (s, n) => String(s).padEnd(n);
const lpad = (s, n) => String(s).padStart(n);

// ───────────────────────── compare mode ─────────────────────────
if (process.argv[2] === "compare") {
  const [a, b] = process.argv.slice(3).map((f) => JSON.parse(fs.readFileSync(f, "utf8")));
  if (!a || !b) { console.error("Usage: node perf/run.mjs compare <before.json> <after.json>"); process.exit(1); }
  const last = (r) => r.stages[r.stages.length - 1];
  const sa = last(a), sb = last(b);
  const pct = (x, y) => (x ? `${y >= x ? "+" : ""}${fmt(((y - x) / x) * 100, 1)}%` : "—");
  console.log(`\nCompare (last stage): ${a.profile} ${a.startedAt}  →  ${b.profile} ${b.startedAt}\n`);
  if (a.profile !== b.profile || sa.connections !== sb.connections) console.log("⚠ দুটো run এর profile বা connection সংখ্যা আলাদা — তুলনা অর্থবহ নাও হতে পারে\n");
  console.log(pad("scenario", 18) + lpad("req/s before", 14) + lpad("after", 10) + lpad("Δ", 11) + lpad("p99 before", 13) + lpad("after", 11) + lpad("Δ", 11));
  for (const s of sb.scenarios) {
    const o = sa.scenarios.find((x) => x.name === s.name);
    if (!o) continue;
    console.log(pad(s.name, 18) + lpad(fmt(o.rps), 14) + lpad(fmt(s.rps), 10) + lpad(pct(o.rps, s.rps), 11) + lpad(`${fmt(o.p99)}ms`, 13) + lpad(`${fmt(s.p99)}ms`, 11) + lpad(pct(o.p99, s.p99), 11));
  }
  console.log(pad("TOTAL", 18) + lpad(fmt(sa.totalRps), 14) + lpad(fmt(sb.totalRps), 10) + lpad(pct(sa.totalRps, sb.totalRps), 11));
  console.log(`\nError rate: ${fmt(sa.errorRate * 100, 2)}% → ${fmt(sb.errorRate * 100, 2)}%\n`);
  process.exit(0);
}

// ───────────────────────── run mode ─────────────────────────
const profileName = process.argv[2] || "smoke";
const stages = cfg.profiles[profileName];
if (!stages) { console.error(`Unknown profile "${profileName}". Use: ${Object.keys(cfg.profiles).join(", ")} or compare`); process.exit(1); }

// ---- auth ----
async function getToken() {
  if (process.env.TOKEN) return process.env.TOKEN;
  if (!cfg.mix.some((m) => m.auth) || !cfg.login) return null;
  try {
    const res = await fetch(cfg.baseUrl + cfg.login.path, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(cfg.login.body) });
    const json = await res.json();
    const token = cfg.login.tokenPath.split(".").reduce((o, k) => o?.[k], json);
    if (!token) throw new Error(`token not found at "${cfg.login.tokenPath}" (status ${res.status})`);
    return token;
  } catch (e) {
    console.error(`⚠ Login failed: ${e.message}. Auth scenarios will get 401. Set TOKEN env or fix scenarios.mjs → login.`);
    return null;
  }
}

// ---- /metrics sampler (prom-client) ----
const metricRe = (name) => new RegExp(`^${name}(?:\\{[^}]*\\})?\\s+([0-9.eE+-]+)`, "m");
async function sampleMetrics() {
  try {
    const ctrl = AbortSignal.timeout(1500);
    const txt = await (await fetch(cfg.metricsUrl, { signal: ctrl })).text();
    const get = (n) => { const m = txt.match(metricRe(n)); return m ? Number(m[1]) : null; };
    return { t: Date.now(), lagP99: get("nodejs_eventloop_lag_p99_seconds"), heap: get("nodejs_heap_size_used_bytes"), rss: get("process_resident_memory_bytes"), cpu: get("process_cpu_seconds_total") };
  } catch { return null; }
}

// ---- build autocannon requests ----
const build = (r, token) => ({
  method: r.method || "GET",
  setupRequest: (req) => {
    req.path = typeof r.path === "function" ? r.path() : r.path;
    const headers = { ...(r.headers || {}) };
    if (token) headers.authorization = `Bearer ${token}`;
    if (r.body !== undefined) {
      req.body = JSON.stringify(typeof r.body === "function" ? r.body() : r.body);
      headers["content-type"] = "application/json";
    }
    req.headers = headers;
    return req;
  },
});

async function runStage(stage, token, idx) {
  const totalW = cfg.mix.reduce((a, m) => a + m.weight, 0);
  const samples = [];
  const first = await sampleMetrics();
  if (first) samples.push(first);
  const timer = setInterval(async () => { const s = await sampleMetrics(); if (s) samples.push(s); }, 2000);

  const runs = cfg.mix.map((m) => {
    const connections = Math.max(1, Math.round((stage.connections * m.weight) / totalW));
    return autocannon({
      url: cfg.baseUrl,
      connections,
      duration: stage.duration,
      timeout: 10,
      requests: m.requests.map((r) => build(r, m.auth ? token : null)),
    }).then((res) => ({ m, connections, res }));
  });

  const label = stage.label ? ` (${stage.label})` : "";
  process.stdout.write(`▶ stage ${idx + 1}/${stages.length}${label}: ${stage.connections} connections × ${stage.duration}s ... `);
  const done = await Promise.all(runs);
  clearInterval(timer);
  const last = await sampleMetrics();
  if (last) samples.push(last);

  const scenarios = done.map(({ m, connections, res }) => {
    const ok = res["2xx"] ?? 0;
    const bad = (res.errors || 0) + (res.timeouts || 0) + (res.non2xx || 0);
    return {
      name: m.name, connections,
      total: ok + bad, sent: res.requests.sent ?? ok + bad, ok, errors: res.errors || 0, timeouts: res.timeouts || 0, non2xx: res.non2xx || 0,
      rps: res.requests.average,
      avg: res.latency.average, p50: res.latency.p50, p90: res.latency.p90, p97_5: res.latency.p97_5, p99: res.latency.p99, max: res.latency.max,
      statusCodes: res.statusCodeStats || {},
    };
  });
  const total = scenarios.reduce((a, s) => a + s.total, 0);
  const bad = scenarios.reduce((a, s) => a + s.errors + s.timeouts + s.non2xx, 0);
  const lags = samples.map((s) => s.lagP99).filter((v) => v != null);
  const heaps = samples.map((s) => s.heap).filter((v) => v != null);
  const cpuSec = first?.cpu != null && last?.cpu != null ? last.cpu - first.cpu : null;

  const r = {
    ...stage, scenarios, total, errorRate: total ? bad / total : 0,
    totalRps: scenarios.reduce((a, s) => a + s.rps, 0),
    server: samples.length ? {
      maxEventLoopLagMs: lags.length ? Math.max(...lags) * 1000 : null,
      heapStartMB: heaps.length ? heaps[0] / 1048576 : null,
      heapEndMB: heaps.length ? heaps[heaps.length - 1] / 1048576 : null,
      heapMaxMB: heaps.length ? Math.max(...heaps) / 1048576 : null,
      avgCpuPct: cpuSec != null ? (cpuSec / stage.duration) * 100 : null,
    } : null,
  };

  // thresholds
  const t = cfg.thresholds;
  r.failures = [];
  for (const s of scenarios) {
    // server overload হলে কোনো scenario একটাও response না পেলে latency 0 দেখায় — এটা pass না
    if (s.total === 0) { r.failures.push(`${s.name}: 0 completed responses (${s.sent} sent) — server starved this scenario`); continue; }
    if (s.sent > 0 && s.total / s.sent < 0.9) r.failures.push(`${s.name}: only ${fmt((s.total / s.sent) * 100)}% of sent requests completed`);
    if (t.p97_5Ms && s.p97_5 > t.p97_5Ms) r.failures.push(`${s.name}: p97.5 ${fmt(s.p97_5)}ms > ${t.p97_5Ms}ms`);
    if (t.p99Ms && s.p99 > t.p99Ms) r.failures.push(`${s.name}: p99 ${fmt(s.p99)}ms > ${t.p99Ms}ms`);
  }
  if (t.errorRate != null && r.errorRate > t.errorRate) r.failures.push(`error rate ${fmt(r.errorRate * 100, 2)}% > ${t.errorRate * 100}%`);
  if (t.eventLoopLagMs && r.server?.maxEventLoopLagMs > t.eventLoopLagMs) r.failures.push(`event loop lag ${fmt(r.server.maxEventLoopLagMs)}ms > ${t.eventLoopLagMs}ms`);
  r.passed = r.failures.length === 0;
  console.log(r.passed ? "✓ pass" : "✗ FAIL");
  return r;
}

function printStage(r, i) {
  const label = r.label ? ` · ${r.label}` : "";
  console.log(`\n── Stage ${i + 1}${label} · ${r.connections} conn · ${r.duration}s · ${fmt(r.totalRps)} req/s · errors ${fmt(r.errorRate * 100, 2)}% ${r.passed ? "✓" : "✗"}`);
  console.log("  " + pad("scenario", 16) + lpad("conn", 6) + lpad("req/s", 9) + lpad("p50", 8) + lpad("p97.5", 8) + lpad("p99", 8) + lpad("max", 8) + lpad("non2xx", 8) + lpad("err", 6));
  for (const s of r.scenarios) console.log("  " + pad(s.name, 16) + lpad(s.connections, 6) + lpad(fmt(s.rps), 9) + lpad(fmt(s.p50), 8) + lpad(fmt(s.p97_5), 8) + lpad(fmt(s.p99), 8) + lpad(fmt(s.max), 8) + lpad(fmt(s.non2xx), 8) + lpad(fmt(s.errors + s.timeouts), 6));
  if (r.server) console.log(`  server: event loop lag max ${fmt(r.server.maxEventLoopLagMs, 1)}ms · CPU ~${fmt(r.server.avgCpuPct)}% · heap ${fmt(r.server.heapStartMB)} → ${fmt(r.server.heapEndMB)} MB (max ${fmt(r.server.heapMaxMB)})`);
  for (const f of r.failures) console.log(`  ✗ ${f}`);
}

// ---- main ----
const startedAt = new Date().toISOString();
console.log(`\nautocannon runner · profile "${profileName}" · ${cfg.baseUrl} · ${cfg.mix.map((m) => `${m.name} ${m.weight}%`).join(", ")}\n`);
const health = await fetch(cfg.baseUrl).then(() => true).catch(() => false);
if (!health) { console.error(`✗ ${cfg.baseUrl} এ server পাওয়া যাচ্ছে না। আগে API চালু করো বা BASE_URL ঠিক করো।`); process.exit(1); }

const token = await getToken();
const results = [];
for (let i = 0; i < stages.length; i++) {
  const r = await runStage(stages[i], token, i);
  results.push(r);
  if (profileName === "stress" && !r.passed) break; // breaking point পাওয়া গেছে
}
results.forEach(printStage);

// ---- profile-specific verdicts ----
const notes = [];
let spikeRecovered = null;
if (profileName === "stress") {
  const passed = results.filter((r) => r.passed);
  const lastOk = passed[passed.length - 1];
  const broke = results.find((r) => !r.passed);
  notes.push(lastOk ? `Capacity: ${lastOk.connections} connections ≈ ${fmt(lastOk.totalRps)} req/s within thresholds` : "Capacity: even the first stage failed thresholds");
  if (broke) notes.push(`Breaking point: ${broke.connections} connections → ${broke.failures.join("; ")}`);
  else notes.push("No breaking point reached — add bigger stages in scenarios.mjs");
}
if (profileName === "spike" && results.length >= 3) {
  const [before, , after] = results;
  const p99 = (r) => Math.max(...r.scenarios.map((s) => s.p99));
  const ratio = p99(after) / Math.max(1, p99(before));
  spikeRecovered = before.passed && after.passed && ratio <= 1.5;
  notes.push(`Recovery: worst p99 before ${fmt(p99(before))}ms → after spike ${fmt(p99(after))}ms (${fmt(ratio, 2)}×) — ${spikeRecovered ? "recovered ✓" : "did NOT recover ✗"}`);
  notes.push(`During spike: ${results[1].passed ? "stayed within thresholds" : "thresholds broken (expected) — " + results[1].failures.length + " violations"}`);
}
if (profileName === "soak" && results[0]?.server?.heapStartMB) {
  const s = results[0].server;
  const growth = ((s.heapEndMB - s.heapStartMB) / s.heapStartMB) * 100;
  notes.push(`Heap: ${fmt(s.heapStartMB)} → ${fmt(s.heapEndMB)} MB (${fmt(growth, 1)}%) — ${growth > 50 ? "possible memory leak ✗ (take heap snapshots)" : "stable ✓"}`);
}
// stress: breaking point খোঁজাই উদ্দেশ্য, তাই প্রথম stage pass করলেই PASS
// spike: spike এর সময় ভাঙা স্বাভাবিক, আসল প্রশ্ন হলো recover করলো কিনা
const allPassed =
  profileName === "stress" ? results[0]?.passed === true
  : profileName === "spike" && spikeRecovered !== null ? spikeRecovered
  : results.every((r) => r.passed);
console.log(`\n${notes.map((n) => "• " + n).join("\n")}${notes.length ? "\n" : ""}\nRESULT: ${allPassed ? "✓ PASS" : "✗ FAIL"}`);

// ---- save ----
fs.mkdirSync(resultsDir, { recursive: true });
const stamp = startedAt.replace(/[:.]/g, "-").slice(0, 19);
const out = { profile: profileName, startedAt, baseUrl: cfg.baseUrl, thresholds: cfg.thresholds, passed: allPassed, notes, stages: results };
const jsonFile = path.join(resultsDir, `${profileName}-${stamp}.json`);
fs.writeFileSync(jsonFile, JSON.stringify(out, null, 2));
const md = [
  `# ${profileName} — ${allPassed ? "PASS" : "FAIL"}`, ``, `${startedAt} · ${cfg.baseUrl}`, ``,
  ...notes.map((n) => `- ${n}`), ``,
  ...results.flatMap((r, i) => [
    `## Stage ${i + 1}${r.label ? ` (${r.label})` : ""} — ${r.connections} connections, ${r.duration}s — ${r.passed ? "✓" : "✗"}`, ``,
    `| Scenario | Conn | Req/s | p50 | p97.5 | p99 | Max | non-2xx | Errors |`, `|---|---|---|---|---|---|---|---|---|`,
    ...r.scenarios.map((s) => `| ${s.name} | ${s.connections} | ${fmt(s.rps)} | ${fmt(s.p50)} | ${fmt(s.p97_5)} | ${fmt(s.p99)} | ${fmt(s.max)} | ${s.non2xx} | ${s.errors + s.timeouts} |`),
    ``, r.server ? `Server: event loop lag max ${fmt(r.server.maxEventLoopLagMs, 1)} ms · CPU ~${fmt(r.server.avgCpuPct)}% · heap ${fmt(r.server.heapStartMB)} → ${fmt(r.server.heapEndMB)} MB` : "", ``,
    ...r.failures.map((f) => `- ✗ ${f}`), ``,
  ]),
].join("\n");
fs.writeFileSync(jsonFile.replace(/\.json$/, ".md"), md);
console.log(`\nSaved: ${path.relative(process.cwd(), jsonFile)} (+ .md)\n`);
process.exit(allPassed ? 0 : 1);
